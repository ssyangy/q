
SeaJS is a new kind of JavaScript Loader that makes it easy to build scalable web applications. SeaJS is designed to change the way you write JavaScript.

<http://seajs.com/>


## Vision

海纳百川，有容乃大。

The sea can hold the water from thousands of rivers, it's big because of its capacity.


## License

SeaJS is available under the terms of the [MIT license](https://github.com/tannhu/jsface/blob/master/MIT-LICENSE.txt).


## Some more thing

Question, comments, feedbacks please go to [SeaJS Group](http://groups.google.com/group/seajs).
