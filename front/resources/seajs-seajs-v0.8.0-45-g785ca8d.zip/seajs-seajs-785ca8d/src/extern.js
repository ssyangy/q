// extern file for google closure compiler
var seajs;
