define(function(require) {

  require('./hello').sayHello();

});
