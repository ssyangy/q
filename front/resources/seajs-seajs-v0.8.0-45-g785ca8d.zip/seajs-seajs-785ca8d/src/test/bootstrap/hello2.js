define(function(require, exports) {

  exports.sayHello = function() {
    document.getElementById('out2').innerHTML = '<span style="color: green">It works! 2</span>';
  };

});
