define(function(require, exports) {

  console.log('a factory');

  exports.a = 'a';

});
