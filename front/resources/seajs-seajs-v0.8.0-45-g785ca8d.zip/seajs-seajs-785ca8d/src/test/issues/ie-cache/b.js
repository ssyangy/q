define(function(require, exports) {

  console.log('b factory');

  exports.b = 'b';

});
