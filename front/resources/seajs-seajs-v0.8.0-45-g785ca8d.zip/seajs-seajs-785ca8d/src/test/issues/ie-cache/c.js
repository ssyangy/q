define(function(require, exports) {

  console.log('c factory');

  exports.c = 'c';

});
