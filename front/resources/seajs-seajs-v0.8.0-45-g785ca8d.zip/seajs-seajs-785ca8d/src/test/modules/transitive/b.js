define(function(require, exports) {

  exports.foo = require('./c').foo;

});
