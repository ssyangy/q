define(function(require, exports) {

  exports.foo = 'c2';

});
