define(function(require, exports) {

  exports.foo = 'a';

});
