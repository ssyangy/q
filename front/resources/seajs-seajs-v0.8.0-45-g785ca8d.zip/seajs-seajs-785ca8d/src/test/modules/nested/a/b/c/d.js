define(function(require, exports) {

  exports.foo = function () {
    return 1;
  };

});
